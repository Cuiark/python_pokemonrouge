import globals
#import all_skills as ski
import json
import random
import json

def get_pokemon_stats_by_name(name, file_path='poketmp.json'):
    try:
        # 读取 poketmp.json 文件
        with open(file_path, 'r', encoding='utf-8') as file:
            data = json.load(file)

        # 遍历 poketmp 数据查找对应名字的宝可梦
        for poke_data in data:
            for poke_id, attributes in poke_data.items():
                if attributes['name'] == name:
                    # 找到匹配的宝可梦，返回其属性
                    return attributes["atk"],attributes["Def"],attributes["spd"],attributes["hp"],attributes["exp"]

        # 如果未找到该宝可梦
        return f"没有找到名字为 {name} 的宝可梦。"

    except FileNotFoundError:
        return "poketmp.json 文件未找到！"
    except json.JSONDecodeError:
        return "文件内容解析错误！"
class poke_base:
    def __init__(self, name, attribute, attributes, ATK, DEF, SPD, ACC, HP, Hp, EXP, atk, Def, spd, hp, NeedEXP, exp, learn_skills, skills=[]):
        self.name = name
        self.attribute = attribute
        self.attributes = attributes
        self.ATK = ATK
        self.DEF = DEF
        self.SPD = SPD
        self.ACC = ACC
        self.HP = HP
        self.Hp = Hp
        self.EXP = EXP
        self.atk = atk
        self.Def = Def
        self.spd = spd
        self.hp = hp
        self.NeedEXP = NeedEXP
        self.exp = exp
        self.skills = skills  # 只存储技能名称和PP
        self.learn_skills = learn_skills or {}

    def create_instance(self, level=1):
        return playerpoke(self, level)

    def IsAlive(self):
        return self.Hp > 0

    def to_dict(self):
        # 只保存技能名称和剩余PP
        return {
            "name": self.name,
            "attribute": self.attribute,
            "attributes": self.attributes,
            "level": self.level,
            "ATK": self.ATK,
            "DEF": self.DEF,
            "SPD": self.SPD,
            "HP": self.HP,
            "skills": [{"name": skill.name, "Pp": skill.Pp} for skill in self.skills],  # 保存技能名称和剩余PP
            "learn_skills": self.learn_skills,
        }
class playerpoke:
    def __init__(self, temp, level=1):
        self.temp = temp
        self.name = temp.name
        self.attribute = temp.attribute
        self.attributes = temp.attributes
        self.level = level
        self.ATK = temp.ATK + temp.atk * level
        self.DEF = temp.DEF + temp.Def * level
        self.SPD = temp.SPD + temp.spd * level
        self.ACC = temp.ACC
        self.HP = temp.HP + temp.hp * level
        self.Hp = temp.Hp + temp.hp * level
        self.EXP = temp.EXP
        self.skills = temp.skills
        self.learn_skills = temp.learn_skills
        self.NeedEXP = temp.NeedEXP + temp.exp * level * level
        self.get_skill()

    def exp_up(self, exp):
        self.EXP = self.EXP + exp
        while self.EXP >= self.NeedEXP:
            self.EXP - self.NeedEXP
            self.level = self.level + 1
            self.ATK = self.ATK + self.temp.atk
            self.DEF = self.DEF + self.temp.Def
            self.SPD = self.SPD + self.temp.spd
            self.HP = self.HP + self.temp.hp
            self.Hp = self.Hp + self.temp.hp
            self.NeedEXP = self.NeedEXP + self.temp.exp * self.level * self.level
            self.get_skill()

    def get_skill(self):
        for skill in self.learn_skills:
            if skill["level"] <= self.level:
                if len(self.skills) < 4:
                    self.skills.append(skill["name"])
                else:
                    self.change_skills(skill["name"])

    def change_skills(self, name):
        a = input("是否遗忘一个技能[y/n]:")
        if a == "n":
            return
        else:
            pop_name = input("选择要遗忘的技能" + str(self.skills))
            print("....{}遗忘了{}".format(self.name, pop_name))
            self.skills.pop(self.skills.index(pop_name))
            print("....{}学会了{}".format(self.name, name))
            self.skills.append(name)

    def to_dict(self):
        return {
            "name": self.name,
            "attribute": self.attribute,
            "attributes": self.attributes,
            "level": self.level,
            "ATK": self.ATK,
            "DEF": self.DEF,
            "SPD": self.SPD,
            "HP": self.HP,
            "skills": self.skills,
            "learn_skills": self.learn_skills,
        }
class wildpoke:
    def __init__(self, temp, level=1):
        self.temp = temp
        self.name = temp.name
        self.attribute = temp.attribute
        self.attributes = temp.attributes
        self.level = level
        self.ATK = temp.ATK + temp.atk * level
        self.DEF = temp.DEF + temp.Def * level
        self.SPD = temp.SPD + temp.spd * level
        self.ACC = temp.ACC
        self.HP = temp.HP + temp.hp * level
        self.Hp = temp.Hp + temp.hp * level
        self.EXP = temp.EXP
        self.learn_skills = temp.learn_skills
        self.skills = self.get_random_skills(temp.learn_skills)
        self.NeedEXP = temp.NeedEXP + temp.exp * level * level

    def get_random_skills(self, learn_skills):
        """
        从 learn_skills 随机选择最多 4 个技能作为初始技能。
        """
        available_skills = [skill['name'] for skill in learn_skills if skill['level'] <= self.level]
        selected_skills = random.sample(available_skills, min(len(available_skills), 4))
        return [{"name": skill, "PP": 20, "Pp": 20} for skill in selected_skills]

    def IsAlive(self):
        return self.Hp > 0

    def to_dict(self):
        return {
            "name": self.name,
            "attribute": self.attribute,
            "level": self.level,
            "ATK": self.ATK,
            "DEF": self.DEF,
            "SPD": self.SPD,
            "HP": self.HP,
            "skills": self.skills,
        }


#name,attribute,attributes,ATK,DEF,SPD,ACC,HP,Hp,EXP,atk,Def,spd,hp,NeedEXP,exp,learn_skills,skills=[]
class PlayerPoke(poke_base):
    def __init__(self, filepoke):
        # 使用 super 调用父类构造函数，传递所有需要的参数
        a,b,c,d,e=get_pokemon_stats_by_name(filepoke["name"])
        super().__init__(
            name=filepoke["name"],
            attribute=filepoke["attribute"],
            attributes=filepoke["attributes"],
            ATK=filepoke["ATK"],
            DEF=filepoke["DEF"],
            SPD=filepoke["SPD"],
            ACC=filepoke["ACC"],
            HP=filepoke["HP"],
            Hp=filepoke["Hp"],
            EXP=filepoke["EXP"],
            NeedEXP=filepoke["NeedEXP"],
            learn_skills=filepoke["learn_skills"],
            skills=filepoke["skills"],
            atk=a,
            Def=b,
            spd=c,
            hp=d,
            exp=e
        )
        self.level = filepoke["level"]

pokemons = []

with open('poketmp.json','r+',encoding="utf-8") as temp:
    data = json.loads(temp.read())
    for poke_id, attributes in data[0].items():
        pokemon = poke_base(**attributes)
        pokemons.append((poke_id, pokemon))
