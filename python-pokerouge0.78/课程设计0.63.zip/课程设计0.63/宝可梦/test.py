import all_poke
import randompoke
import players
import globals
name = input("you name: ")
player1 = players.Player.login(name)
globals.battle(player1,randompoke.randompokes())