import pygame
from pygame.locals import *
import players
import all_poke
import random
import time
import globals
import randompoke
import os

# 初始化 Pygame
pygame.init()
pygame.mixer.init()
global running, game_state
menu = None  # 添加菜单实例变量
# 设置窗口大小和基本参数
WIDTH = 1200
HEIGHT = 800
FPS = 60
screen = pygame.display.set_mode((WIDTH, HEIGHT))
clock = pygame.time.Clock()
pygame.display.set_caption("宝可梦小游戏")

# 定义颜色
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
BLUE = (0, 0, 255)
GREEN = (60, 179, 113)

# 载入图片
ming_baokemeng = pygame.image.load(os.path.join("游戏名.png")).convert()
ming_man = pygame.image.load(os.path.join("男生e.png")).convert()
background_2 = pygame.image.load(os.path.join("初始界面.png")).convert()
# 这里需要添加战斗场景需要的图片
battle_background = pygame.image.load(os.path.join("战斗背景.png")).convert()
# 添加宝可梦图片
pokemon_images = {}  # 创建宝可梦图片字典

# 载入音频
pygame.mixer.music.load(os.path.join("shoot.wav"))


# ... (InputBox类和其他辅助函数保持不变)
class InputBox:
    def __init__(self, x, y, w, h, font_size=32):
        self.rect = pygame.Rect(x, y, w, h)
        self.color = BLACK
        self.text = ""
        self.font = pygame.font.SysFont('SimHei', font_size)
        self.txt_surface = self.font.render(self.text, True, self.color)
        self.cursor = True
        self.cursor_time = time.time()
        self.cursor_pos = 0

    def handle_event(self, event):
        if event.type == KEYDOWN:
            if event.key == K_RETURN:
                return self.text
            elif event.key == K_BACKSPACE:
                self.text = self.text[:self.cursor_pos - 1] + self.text[self.cursor_pos:]
                self.cursor_pos = max(0, self.cursor_pos - 1)
            elif event.key == K_LEFT:
                self.cursor_pos = max(0, self.cursor_pos - 1)
            elif event.key == K_RIGHT:
                self.cursor_pos = min(len(self.text), self.cursor_pos + 1)
            else:
                self.text = self.text[:self.cursor_pos] + event.unicode + self.text[self.cursor_pos:]
                self.cursor_pos += len(event.unicode)
            self.txt_surface = self.font.render(self.text, True, self.color)
        return None

    def draw(self, screen):
        pygame.draw.rect(screen, self.color, self.rect, 2)
        screen.blit(self.txt_surface, (self.rect.x + 5, self.rect.y + 5))

        if time.time() - self.cursor_time > 0.5:
            self.cursor = not self.cursor
            self.cursor_time = time.time()

        if self.cursor:
            cursor_x = self.rect.x + 5 + self.font.size(self.text[:self.cursor_pos])[0]
            cursor_y = self.rect.y + 5
            pygame.draw.line(screen, self.color,
                             (cursor_x, cursor_y),
                             (cursor_x, cursor_y + self.font.get_height()),
                             2)


def draw_text(surf, text, size, x, y):
    font = pygame.font.SysFont('SimHei', size)
    text_surface = font.render(text, True, BLACK)
    text_rect = text_surface.get_rect()
    text_rect.midtop = (x, y)
    surf.blit(text_surface, text_rect)


def draw_pokemon_selection(screen, choices):
    screen.fill(WHITE)
    draw_text(screen, "选择你的宝可梦", 48, WIDTH // 2, 50)
    y_pos = 150
    for i, (_, pokemon) in enumerate(choices):
        draw_text(screen, f"{i + 1}. {pokemon.name} (属性: {pokemon.attribute})",
                 32, WIDTH // 2, y_pos + i * 50)


def draw_init():
    screen.fill(WHITE)
    screen.blit(ming_baokemeng, (350, 100))
    draw_text(screen, "按空格键开始游戏", 64, WIDTH / 2, HEIGHT * 2 / 3)
    pygame.display.update()

    waiting = True
    while waiting:
        clock.tick(FPS)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:  # 按ESC键打开菜单
                    if game_state == BATTLE:
                        game_state = MENU
                        menu = MainMenu(screen)
            if game_state == MENU:
                menu.handle_event(event)

#添加主菜单按钮类
class MenuButton:
    def __init__(self, x, y, w, h, text, action):
        self.rect = pygame.Rect(x, y, w, h)
        self.text = text
        self.action = action
        self.color = (60, 179, 113)  # 绿色
        self.hover_color = (50, 150, 100)  # 深绿色
        self.is_hovered = False
        self.font = pygame.font.SysFont('SimHei', 32)

    def draw(self, screen):
        color = self.hover_color if self.is_hovered else self.color
        pygame.draw.rect(screen, color, self.rect)
        pygame.draw.rect(screen, BLACK, self.rect, 2)  # 边框
        text_surface = self.font.render(self.text, True, WHITE)
        text_rect = text_surface.get_rect(center=self.rect.center)
        screen.blit(text_surface, text_rect)

    def handle_event(self, event):
        if event.type == pygame.MOUSEMOTION:
            self.is_hovered = self.rect.collidepoint(event.pos)
        elif event.type == pygame.MOUSEBUTTONDOWN:
            if self.rect.collidepoint(event.pos):
                self.action()

#添加主菜单类
class MainMenu:
    def __init__(self, screen):
        self.screen = screen
        button_width = 200
        button_height = 50
        start_x = WIDTH // 2 - button_width // 2
        start_y = HEIGHT // 2

        self.buttons = [
            MenuButton(start_x, start_y+ 70, button_width, button_height,
                       "继续游戏", self.continue_game),
            MenuButton(start_x, start_y + 140, button_width, button_height,
                       "返回主页", self.return_to_title),
            MenuButton(start_x, start_y + 210, button_width, button_height,
                       "退出游戏", self.quit_game)
        ]

    def draw(self):
        self.screen.fill(WHITE)
        screen.blit(ming_baokemeng, (350, 100))
        for button in self.buttons:
            button.draw(self.screen)

    def handle_event(self, event):
        for button in self.buttons:
            button.handle_event(event)

    def continue_game(self):
        global game_state
        game_state = BATTLE

    def return_to_title(self):
        global game_state
        game_state = INIT

    def quit_game(self):
        global running
        running = False

class BattleScene:
    def __init__(self, player, enemy):
        self.player = player
        self.enemy = enemy
        self.state = "选择行动"
        self.current_pokemon = player.get_active_pokemon()
        self.enemy_pokemon = enemy.get_active_pokemon()

    def draw(self, screen):
        # 绘制战斗场景
        screen.blit(battle_background, (0, 0))

        # 绘制玩家宝可梦
        if self.current_pokemon:
            # 绘制宝可梦图片和状态
            self.draw_pokemon_status(screen, self.current_pokemon, True)

        # 绘制敌方宝可梦
        if self.enemy_pokemon:
            self.draw_pokemon_status(screen, self.enemy_pokemon, False)

        # 绘制选项菜单
        self.draw_battle_menu(screen)

    def draw_pokemon_status(self, screen, pokemon, is_player):
        # 绘制宝可梦状态信息(HP条、等级等)
        x = 50 if is_player else WIDTH - 250
        y = HEIGHT - 200 if is_player else 50

        # 绘制名字和等级
        draw_text(screen, f"{pokemon.name} Lv.{pokemon.level}", 32, x, y)

        # 绘制HP条
        hp_percent = pokemon.Hp / pokemon.HP
        pygame.draw.rect(screen, BLACK, (x, y + 30, 200, 20), 2)
        pygame.draw.rect(screen, GREEN, (x, y + 30, 200 * hp_percent, 20))

    def draw_battle_menu(self, screen):
        # 绘制战斗选项
        menu_rect = pygame.Rect(0, HEIGHT - 150, WIDTH, 150)
        pygame.draw.rect(screen, WHITE, menu_rect)
        pygame.draw.rect(screen, BLACK, menu_rect, 2)

        if self.state == "选择行动":
            options = ["战斗", "宝可梦", "道具", "逃跑"]
            for i, option in enumerate(options):
                draw_text(screen, option, 32, WIDTH / 4 * (i + 0.5), HEIGHT - 100)

        elif self.state == "选择技能":
            # 显示技能列表
            for i, skill in enumerate(self.current_pokemon.skills):
                draw_text(screen, skill["name"], 32, WIDTH / 4 * (i + 0.5), HEIGHT - 100)

    def handle_event(self, event):
        if event.type == MOUSEBUTTONDOWN:
            # 处理点击事件
            pass
        elif event.type == KEYDOWN:
            # 处理按键事件
            pass


# 游戏状态
INIT = "init"
INPUT_NAME = "input_name"
SELECT_POKEMON = "select_pokemon"
BATTLE = "battle"
MENU = "menu"#主菜单
# 游戏主循环
game_state = INIT
running = True
player = None
pokemon_choices = None
input_box = InputBox(WIDTH // 2 - 150, HEIGHT *5/6, 300, 40)
battle_scene = None

# 播放背景音乐
pygame.mixer.music.play(-1)

while running:
    clock.tick(FPS)

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_ESCAPE:  # 按ESC键打开菜单
                if game_state == BATTLE:
                    game_state = MENU
                    menu = MainMenu(screen)  # 创建菜单实例

        if game_state == MENU:
            menu.handle_event(event)
        elif game_state == BATTLE:
            if battle_scene:
                battle_scene.handle_event(event)
        elif game_state == INIT:
            if event.type == KEYUP and event.key == K_SPACE:
                game_state = INPUT_NAME



        elif game_state == INPUT_NAME:
            result = input_box.handle_event(event)
            if result:
                player, is_new_player = players.Player.login(result)
                if is_new_player:
                    pokemon_choices = random.sample(all_poke.pokemons, 3)
                    game_state = SELECT_POKEMON
                else:
                    # 创建战斗场景
                    battle_scene = globals.BattleSystem(screen, player, randompoke.randompokes())
                    game_state = BATTLE



        elif game_state == SELECT_POKEMON and event.type == KEYDOWN:
            if event.unicode in ["1", "2", "3"]:
                idx = int(event.unicode) - 1
                if idx < len(pokemon_choices):
                    poke_id, pokemon_base = pokemon_choices[idx]
                    pokemon = all_poke.playerpoke(pokemon_base, level=5)
                    player.add_pokemon(pokemon)
                    # 直接使用globals.py中的战斗系统
                    battle_result = globals.battle(player, randompoke.randompokes())
                    if battle_result == "win":
                        draw_text(screen, "恭喜你赢得了战斗!", 64, WIDTH / 2, HEIGHT / 2)
                    elif battle_result == "lose":
                        draw_text(screen, "很遗憾,你输了!", 64, WIDTH / 2, HEIGHT / 2)
                    pygame.display.flip()
                    pygame.time.wait(2000)  # 显示结果2秒
                    running = False
        elif game_state == BATTLE:
            battle_scene.handle_event(event)

    # 绘制界面
    screen.fill(WHITE)
    if game_state == MENU:
        menu.draw()
    elif game_state == BATTLE:
        if battle_scene:
            battle_scene.draw()
    elif game_state == INIT:
        screen.blit(ming_baokemeng, (350, 100))
        draw_text(screen, "按空格键开始游戏", 64, WIDTH / 2, HEIGHT * 2 / 3)

    elif game_state == INPUT_NAME:
        screen.blit(ming_baokemeng, (350, 100))
        draw_text(screen, "请输入你的名字:", 48, WIDTH // 2, HEIGHT * 2 / 3)
        input_box.draw(screen)


    elif game_state == SELECT_POKEMON and pokemon_choices:
        draw_pokemon_selection(screen, pokemon_choices)


    elif game_state == BATTLE:
        if battle_scene:
            battle_scene.draw()
    pygame.display.flip()

pygame.quit()