import players
name_player = input("你的名字:")
player1 = players.player(name_player)
players.choose_pokemons()