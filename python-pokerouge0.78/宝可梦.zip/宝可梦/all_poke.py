import globals
#import all_skills as ski
import json
class poke_base:
    def __init__(self,name,attribute,attributes,ATK,DEF,SPD,ACC,HP,Hp,EXP,atk,Def,spd,hp,NeedEXP,exp,skill1,skill2,skill3,skill4):
        self.name = name
        self.attribute = attribute
        self.attributes = attributes
        self.ATK = ATK
        self.DEF = DEF
        self.SPD = SPD
        self.ACC = ACC
        self.HP = HP
        self.Hp = Hp
        self.EXP = EXP
        self.atk = atk
        self.Def = Def
        self.spd =spd
        self.hp = hp
        self.NeedEXP = NeedEXP
        self.exp = exp
        self.skills1 = skill1
        self.skills2 = skill2
        self.skills3 = skill3
        self.skills4 = skill4
    def create_instance(self,level = 1):
        return playerpoke(self,level)
    def IsAlive(self):
        return self.Hp > 0
class playerpoke:
    def __init__(self,temp,level = 1):
        self.temp = temp
        self.name = temp.name
        self.attribute = temp.attribute
        self.attributes = temp.attributes
        self.level =level
        self.ATK = temp.ATK + temp.atk * level
        self.DEF = temp.DEF + temp.Def * level
        self.SPD = temp.SPD + temp.spd * level
        self.ACC = temp.ACC
        self.HP = temp.HP + temp.hp * level
        self.Hp = temp.Hp + temp.hp * level
        self.EXP = temp.EXP
        self.NeedEXP = temp.NeedEXP + temp.exp*level*level
    def exp_up(self,exp):
        self.EXP = self.EXP + exp
        while self.EXP >= self.NeedEXP:
            self.EXP - self.NeedEXP
            self.level =self.level + 1
            self.ATK = self.ATK + self.temp.atk
            self.DEF = self.DEF + self.temp.Def
            self.SPD = self.SPD + self.temp.spd
            self.HP = self.HP +self.temp.hp
            self.NeedEXP = self.NeedEXP + self.temp.exp * self.level * self.level



pokemons = []

with open('poketmp.json','r+',encoding="utf-8") as temp:
    data = json.loads(temp.read())
    for poke_id, attributes in data[0].items():
        pokemon = poke_base(**attributes)
        pokemons.append((poke_id, pokemon))

def get_player_pokemon(poke_id,level):
    for pid, pokemon in pokemons:
        if pid == poke_id:
            return pokemon.create_instance(level=level)
    return None  # 如果未找到，返回 None

# 使用封装函数