import all_poke
import random
import time
import all_skills
import json
import all_tools


def battle(player, wild_poke):
    """
    玩家与野生宝可梦进行战斗
    """
    def choose_player_poke():
        """让玩家选择一个活着的宝可梦出战"""
        while True:
            print("请选择一个宝可梦出战：")
            available_pokes = [
                (slot, poke) for slot, poke in player.pokemon_slots.items() if poke and poke["Hp"] > 0
            ]
            if not available_pokes:
                print("你没有可以战斗的宝可梦了！")
                return None
            for idx, (slot, poke) in enumerate(available_pokes, start=1):
                print(f"{idx}. {poke['name']} (槽位: {slot}, 当前Hp: {poke['Hp']})")
            try:
                choice = int(input("输入宝可梦编号：")) - 1
                return available_pokes[choice][1]
            except (ValueError, IndexError):
                print("输入无效，请重新选择！")

    # 获取玩家宝可梦
    player_poke = player.pokemon_slots.get('slot1')  # 假设玩家选择第一个槽位的宝可梦
    if not player_poke:
        print("没有宝可梦在槽位1，请先选择宝可梦！")
        player_poke = choose_player_poke()
        return

    player_poke = all_poke.PlayerPoke(player_poke)  # 获取玩家宝可梦实例

    # 战斗前的初始化
    print(f"战斗开始！\n玩家宝可梦：{player_poke.name} 等级: {player_poke.level}")
    print(f"野生宝可梦：{wild_poke.name} 等级: {wild_poke.level}")
    round = 1
    available_pokes = [
        (slot, poke) for slot, poke in player.pokemon_slots.items() if poke and poke["Hp"] > 0
    ]
    while available_pokes and wild_poke.IsAlive():
        # 显示当前状态
        print(f"\n玩家宝可梦：{player_poke.name} 当前Hp: {player_poke.Hp}")
        print(f"野生宝可梦：{wild_poke.name} 当前Hp: {wild_poke.Hp}\n")
            # 玩家选择技能
        print("请选择你的行动：")
        print("1. 攻击")
        print("2. 使用道具")
        print("3. 退出")
        print("4、更换宝可梦")
        action = input("请输入 1 或 2: ")

        if action == '1':
            # 显示玩家宝可梦可用的技能
            print("\n请选择技能：")
            for idx, skill in enumerate(player_poke.skills, start=1):
                skill_obj = all_skills.get_skill_by_name(skill["name"], skill["Pp"])  # 实例化技能可以调用技能类的函数
                print(skill)
                print(f"{idx}. {skill["name"]} (PP: {skill["Pp"]})")

            skill_choice = int(input("请输入技能的编号："))
            skill = player_poke.skills[skill_choice - 1]  # 获取玩家选择的技能
            skill_obj = all_skills.get_skill_by_name(skill["name"], skill["Pp"])
            print(skill_obj)
            # 玩家使用技能
            damage = skill_obj.apply(player_poke, wild_poke)
            skill["Pp"] = skill["Pp"] - 1
            all_skills.ApplyDmage(player_poke, wild_poke, damage, skill_obj)
        elif action == '2':
            # 使用道具
            print("\n你的道具:")
            if not player.tools:
                print("你没有任何道具!")
                continue
            # 显示所有道具
            for idx, (tool_name, tool_data) in enumerate(player.tools.items(), 1):
                print(f"{idx}. {tool_data['name']} (数量: {tool_data['num']})")

            print("\n输入道具编号使用，或输入 'q' 返回")
            tool_choice = input("你的选择: ").strip()

            if tool_choice.lower() == 'q':
                continue

            try:
                choice_idx = int(tool_choice) - 1
                if 0 <= choice_idx < len(player.tools):
                    # 获取选择的道具名称
                    tool_name = list(player.tools.keys())[choice_idx]
                    tool_data = player.tools[tool_name
                    all_tools.get_tool_by_name(tool_name)
                    # 选择目标宝可梦
                    print(f"\n使用 {tool_data['name']} 于:")
                    print(f"1. {player_poke.name} (我方, HP: {player_poke.Hp}/{player_poke.HP})")

                    target_choice = input("请选择目标 (输入1): ").strip()
                    if target_choice == '1':
                        if all_tools.: #tool_name,player_poke
                            print(f"成功使用了 {tool_data['name']}!")
                            # 保存玩家宝可梦的状态
                            all_skills.save_player_poke(player)
                        else:
                            print("道具使用失败!")
                    else:
                        print("无效的选择!")
                else:
                    print("无效的道具编号!")
            except ValueError:
                print("请输入有效的数字!")
            pass

        elif action == '3':
            print("选择你的宝可梦:")
            player_poke = choose_player_poke()
            player_poke = all_poke.PlayerPoke(player_poke)

        elif action == '4':
            print("成功逃跑了")
            return

        else:
            print("无效的选择！")
            continue

            # 野生宝可梦攻击玩家宝可梦
        if player_poke.IsAlive() and wild_poke.IsAlive():
            # 野生宝可梦随机选择一个技能攻击玩家宝可梦
            wild_skill = random.choice(wild_poke.skills)
            wild_skill_obj = all_skills.get_skill_by_name(wild_skill["name"], wild_skill["Pp"])  # 实例化技能，使它可以调用函数
            if not wild_skill_obj.has_pp():
                print(f"{wild_poke.name} 的 {wild_skill["name"]} 的 PP 已用完！")
                continue
            wild_skill["Pp"] = wild_skill["Pp"] - 1
            damage = wild_skill_obj.apply(wild_poke, player_poke)
            all_skills.ApplyDmage(wild_poke, player_poke, damage, wild_skill_obj)
            all_skills.save_player_poke(player)
            with open("wildpoke.json", 'w', encoding='utf-8') as file:
                wild_data = {
                    "name": wild_poke.name,
                    "attribute": wild_poke.attribute,
                    "attributes": wild_poke.attributes,
                    "level": wild_poke.level,
                    "ATK": wild_poke.ATK,
                    "DEF": wild_poke.DEF,
                    "SPD": wild_poke.SPD,
                    "ACC": wild_poke.ACC,
                    "HP": wild_poke.HP,
                    "Hp": wild_poke.Hp,
                    "EXP": wild_poke.EXP,
                    "NeedEXP": wild_poke.NeedEXP,
                    "skills": wild_poke.skills,  # 存储技能
                    "learn_skills": wild_poke.learn_skills
                }
                json.dump(wild_data, file, ensure_ascii=False, indent=4)
            # 休息时间，模拟回合切换

        if not player_poke.IsAlive():
            print(f"{player_poke.name} 被击败了！")
            player_poke = choose_player_poke()
            if not player_poke:
                print("你没有可以战斗的宝可梦了！战斗失败！")
                return
            player_poke = all_poke.PlayerPoke(player_poke)  # 切换新的玩家宝可梦

    print("第{}回合".format(round))
    # 战斗结果
    if player_poke.IsAlive():
        print(f"\n{player_poke.name} 胜利！")
        # 玩家胜利后，给予经验奖励
        player_poke.exp_up(10)
        print(f"{player_poke.name} 获得了10点经验！")
    else:
        print(f"\n{wild_poke.name} 胜利！")
        print(f"{player_poke.name} 被击败！")


