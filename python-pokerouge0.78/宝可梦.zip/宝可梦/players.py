import all_poke
#import all_skills
import all_tools
import globals
import random


def choose_pokemons(num_choices=3):
    # 随机选择 3 个宝可梦
    choices = random.sample(all_poke.pokemons, num_choices)
    print("请选择宝可梦 (输入对应编号):")
    for i, (poke_id, pokemon) in enumerate(choices):
        print(f"{i + 1}. {pokemon.name} (ID: {poke_id},属性:{pokemon.attribute})")

    selected_ids = input("输入编号，以逗号分隔: ").split(",")
    selected_pokemons = []

    for selected_id in selected_ids:
        try:
            idx = int(selected_id.strip()) - 1
            if 0 <= idx < len(choices):
                selected_pokemons.append(choices[idx])
        except ValueError:
            print(f"无效输入: {selected_id}")

    return selected_pokemons
class player():
    def __init__(self,name):
        self.name = name
        self.pokemon = []
    def get_poke(self,poke):
        if len(self.pokemon) < 6 :
            self.pokemon.append(poke)
            print("{} pokemon get up !".format(poke.name))
        else :
            print("背包已满，是否放生宝可梦，腾出背包空间")

    def down_poke(self,poke):
        if poke in  self.pokemon:
            self.pokemon.pop(poke)
            print("bye {}".format(poke.name))
        else :
            print("Error")

    def list_pokemons(self):
        if not self.pokemon:
            print("队伍中没有宝可梦。")
        else:
            print("玩家的宝可梦：")
            for idx, pokemon in enumerate(self.pokemon):
                print(f"{idx + 1}. {pokemon.name} 等级: {pokemon.level}")


