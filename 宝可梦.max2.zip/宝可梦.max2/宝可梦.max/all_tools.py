# all_tools.py
from enum import IntEnum, unique
import json
import random

try:
    @unique
    class ToolsType(IntEnum):
        #道具类型
        get_poke = 1
        get_blood = 2
        get_abl = 4
        get_level = 8
        get_life = 16
        get_Pp = 32

    class GetType(IntEnum):
        Get1 = 1 #系数为 1
        Get2 = 2 #系数为 1.5
        Get3 = 3 #系数为3
        Get4 = 4 #系数为4

    class BloodType(IntEnum):
        Blood1 = 1 #20HP
        Blood2 = 2 #60HP
        Blood3 = 4 #120HP
        all_Blood = 8 #全部HP

    class LifeType(IntEnum):
        life = 1 #复活，获得50%Hp
        life_all = 2 #复活，获得全部Hp

    class PpType(IntEnum):
        Pp1 = 1 #恢复10Pp
        Pp2 = 2 #恢复20Pp
        Pp3 = 4 #恢复全部Pp
except ValueError as e:
    print(e)

def get_tool_by_name(name, num, get_type=1):
    """获取道具实例"""
    if name in tool:
        tool_instance = tool[name]
        tool_instance.GetType = get_type  # 设置捕获率
        tool_instance.name = name  # 添加名称属性
        return tool_instance
    return None

def check_tool_type(tool, type_flag):
    """检查道具是否具有特定类型"""
    return bool(tool.ToolsType & type_flag)

class tools:
    def __init__(self, name, num, ToolsType, GetType=None, BloodType=None, LifeType=None, PpType=None):
        self.name = name
        self.num = num
        self.ToolsType = ToolsType
        self.GetType = GetType
        self.BloodType = BloodType
        self.LifeType = LifeType
        self.PpType = PpType

    def UseTools(self, poke):
        """使用道具"""

        # 辅助函数保持不变
        def is_alive(p):
            if isinstance(p, dict):
                return p['Hp'] > 0
            return p.Hp > 0

        def get_attr(p, attr):
            if isinstance(p, dict):
                return p[attr]
            return getattr(p, attr)

        def set_attr(p, attr, value):
            if isinstance(p, dict):
                p[attr] = value
            else:
                setattr(p, attr, value)

        messages = []  # 存储所有提示消息

        if self.ToolsType == ToolsType.get_poke:
            # 根据GetType计算捕获概率
            base_rates = {
                1: 0.3,  # 精灵球 30%基础捕获率
                2: 1.0,  # 超级球 100%基础捕获率
                3: 0.5,  # 高级球 50%基础捕获率
                4: 0.7   # 大师球 70%必定捕获
            }
            
            base_rate = base_rates.get(self.GetType, 0.3)
            
            # 如果是大师球，直接捕获成功
            if self.GetType == 2:
                return True, [f"成功捕获了{poke.name}!"]
            
            # HP越低，捕获率越高
            hp_factor = 1 - (poke.Hp / poke.HP)
            # 等级越高，捕获率越低
            level_factor = max(0.1, 1 - (poke.level / 100))
            
            actual_rate = base_rate * (1 + hp_factor) * level_factor
            
            # 尝试捕获
            if random.random() < actual_rate:
                return True, [f"成功捕获了{poke.name}!"]
            else:
                return False, [f"{poke.name}挣脱了{self.name}!"]

        elif self.ToolsType == ToolsType.get_blood:
            if not is_alive(poke):
                messages.append(f"{get_attr(poke, 'name')} 已经失去战斗能力,不能使用回复药!")
                return False, messages

            heal_amount = 0
            if self.BloodType == BloodType.Blood1:
                heal_amount = 20
            elif self.BloodType == BloodType.Blood2:
                heal_amount = 60
            elif self.BloodType == BloodType.Blood3:
                heal_amount = 120
            elif self.BloodType == BloodType.all_Blood:
                heal_amount = get_attr(poke, 'HP') - get_attr(poke, 'Hp')

            old_hp = get_attr(poke, 'Hp')
            new_hp = min(old_hp + heal_amount, get_attr(poke, 'HP'))
            set_attr(poke, 'Hp', new_hp)
            actual_heal = new_hp - old_hp
            messages.append(f"{get_attr(poke, 'name')} 恢复了 {actual_heal} 点HP!")
            return True, messages

        elif self.ToolsType == ToolsType.get_life:
            if is_alive(poke):
                messages.append(f"{get_attr(poke, 'name')} 还活着,不需要使用复活药!")
                return False, messages

            max_hp = get_attr(poke, 'HP')
            if self.LifeType == LifeType.life:
                set_attr(poke, 'Hp', max_hp // 2)
            elif self.LifeType == LifeType.life_all:
                set_attr(poke, 'Hp', max_hp)
            messages.append(f"{get_attr(poke, 'name')} 复活了,当前HP: {get_attr(poke, 'Hp')}/{max_hp}")
            return True, messages

        elif self.ToolsType == ToolsType.get_abl:
            boost = 1.0
            if self.GetType == GetType.Get1:
                boost = 1.1
            elif self.GetType == GetType.Get2:
                boost = 1.2
            elif self.GetType == GetType.Get3:
                boost = 1.5

            for stat in ['ATK', 'DEF', 'SPD']:
                current = get_attr(poke, stat)
                set_attr(poke, stat, int(current * boost))
            messages.append(f"{get_attr(poke, 'name')} 的能力得到了提升!")
            return True, messages

        elif self.ToolsType == ToolsType.get_level:
            exp_gain = 0
            need_exp = get_attr(poke, 'NeedEXP')
            exp_gain = need_exp 

            if isinstance(poke, dict):
                poke['EXP'] += int(exp_gain)
            else:
                poke.exp_up(int(exp_gain))
            messages.append(f"{get_attr(poke, 'name')} 获得了 {int(exp_gain)} 点经验值!")
            return True, messages

        elif self.ToolsType == ToolsType.get_Pp:
            # 检查是否有需要恢复PP的技能
            skills = get_attr(poke, 'skills')
            need_pp_recovery = False
            for skill in skills:

                if skill['Pp'] < skill['PP']:
                    need_pp_recovery = True
                    break

            if not need_pp_recovery:
                messages.append(f"{get_attr(poke, 'name')} 的所有技能PP都是满的!")
                return False, messages

            # 根据道具类型恢复不同量的PP
            for skill in skills:
                
                if self.PpType == 1:
                    skill['Pp'] = min(skill['PP'], skill['Pp'] + 10)
                elif self.PpType == 2:
                    skill['Pp'] = min(skill['PP'], skill['Pp'] + 20)
                elif self.PpType == 4:
                    skill['Pp'] = skill['PP']
            messages.append(f"{get_attr(poke, 'name')} 的技能PP得到了恢复!")
            return True, messages

        return False, messages

    def _calculate_catch_rate(self, poke):
        """计算宝可梦的捕获率"""
        # 捕获率 = (最大HP×3-当前HP×2)÷(最大HP×3)×精灵捕获系数×精灵球系数×状态系数÷255
        base_rate = (poke.HP * 3 - poke.Hp * 2) / (poke.HP * 3)
        pokemon_factor = 1  # 可以根据宝可梦种类调整
        status_factor = 1  # 可以根据状态(睡眠等)调整
        return base_rate * pokemon_factor * status_factor / 255



tool = {}

with open('tools.json', 'r+', encoding="utf-8") as temp:
    data = json.loads(temp.read())
    for tool_id, attributes in data[0].items():
        attributes['ToolsType'] = ToolsType(attributes['ToolsType'])
        if attributes.get('GetType') not in [None, 0]:
            attributes['GetType'] = GetType(attributes['GetType'])
        else:
            attributes['GetType'] = None

        if attributes.get('BloodType') not in [None, 0]:
            attributes['BloodType'] = BloodType(attributes['BloodType'])
        else:
            attributes['BloodType'] = None

        if attributes.get('LifeType') not in [None, 0]:
            attributes['LifeType'] = LifeType(attributes['LifeType'])
        else:
            attributes['LifeType'] = None

        # 创建道具实例
        tool[tool_id] = tools(**attributes)