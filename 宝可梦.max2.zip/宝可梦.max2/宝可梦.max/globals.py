import pygame
import all_skills
import all_tools
import all_poke
from pygame.locals import *
import random
import json
import randompoke



class GameManager:
    def __init__(self):
        """初始化游戏管理器"""
        self.load_tools_data()

    def load_tools_data(self):
        """加载道具数据"""
        try:
            with open('tools.json', 'r', encoding='utf-8') as f:
                self.tools_data = json.load(f)
        except FileNotFoundError:
            print("Error: tools.json not found")
            self.tools_data = []
        except json.JSONDecodeError:
            print("Error: Invalid JSON in tools.json")
            self.tools_data = []

    def initialize_player_slots(self, player_name, initial_pokemon=None):
        """初始化新玩家的宝可梦槽位"""
        slots = {
            "slot1": initial_pokemon,
            "slot2": None,
            "slot3": None,
            "slot4": None,
            "slot5": None,
            "slot6": None
        }
        try:
            with open('playerpoke.json', 'r', encoding='utf-8') as f:
                poke_data = json.load(f)
        except (FileNotFoundError, json.JSONDecodeError):
            poke_data = {}

        poke_data[player_name] = slots
        with open('playerpoke.json', 'w', encoding='utf-8') as f:
            json.dump(poke_data, f, ensure_ascii=False, indent=4)
        return slots

    def load_player_data(self, player_name):
        """加载玩家宝可梦数据"""
        try:
            with open('playerpoke.json', 'r', encoding='utf-8') as f:
                poke_data = json.load(f)
                if player_name in poke_data:
                    slots = poke_data[player_name]
                    # 检查是否有任何非空槽位
                    has_pokemon = any(slot for slot in slots.values() if slot)
                    if has_pokemon:
                        return slots  # 如果有宝可梦，返回槽位数据
                return None  # 如果没有宝可梦或玩家不存在，返回None
        except FileNotFoundError:
            return None
        except json.JSONDecodeError:
            print("Invalid pokemon save data")
            return None

    def load_player_tools(self, player_name):
        """加载玩家道具数据"""
        try:
            with open('playertools.json', 'r', encoding='utf-8') as f:
                tools_data = json.load(f)
                if player_name in tools_data:
                    return tools_data[player_name]
        except FileNotFoundError:
            return {}
        except json.JSONDecodeError:
            return {}
        return {}

    def save_player_data(self, player):
        """保存玩家数据到文件"""
        # 保存宝可梦数据
        try:
            with open('playerpoke.json', 'r', encoding='utf-8') as f:
                poke_data = json.load(f)
        except (FileNotFoundError, json.JSONDecodeError):
            poke_data = {}

        poke_data[player.name] = player.pokemon_slots
        with open('playerpoke.json', 'w', encoding='utf-8') as f:
            json.dump(poke_data, f, ensure_ascii=False, indent=4)

        # 保存道具数据
        try:
            with open('playertools.json', 'r', encoding='utf-8') as f:
                tools_data = json.load(f)
        except (FileNotFoundError, json.JSONDecodeError):
            tools_data = {}

        tools_data[player.name] = player.tools
        with open('playertools.json', 'w', encoding='utf-8') as f:
            json.dump(tools_data, f, ensure_ascii=False, indent=4)

    def find_empty_slot(self, player):
        """查找空槽位"""
        for slot in ["slot1", "slot2", "slot3", "slot4", "slot5", "slot6"]:
            if not player.pokemon_slots.get(slot):
                return slot
        return None

    def get_exp(self, wild_poke):
        """获取野生宝可梦的经验值"""
        return wild_poke.level * 10 + wild_poke.EXP * 2 * wild_poke.level * 4

    def choose_player_poke(self, player, allow_return=True):
        """选择玩家的宝可梦"""
        # 首先检查玩家是否已经有宝可梦
        for slot, poke in player.pokemon_slots.items():
            if poke:  # 如果找到任何非空的槽位
                return poke  # 直接返回第一个找到的宝可梦
        
        # 如果没有找到任何宝可梦，返回None
        return None

    def reward(self, player):
        """战斗胜利后的奖励系统"""
        available_tools = list(self.tools_data[0].keys())
        tool_rewards = random.sample(available_tools, 2)

        stat_rewards = [
            ("ATK提升", "提升宝可梦的攻击力5点"),
            ("DEF提升", "提升宝可梦的防御力5点"),
            ("SPD提升", "提升宝可梦的速度5点"),
            ("HP提升", "提升宝可梦的最大HP5点"),
            ("ATK成长提升", "提升宝可梦的攻击成长1点"),
            ("DEF成长提升", "提升宝可梦的防御成长1点"),
            ("SPD成长提升", "提升宝可梦的速度成长1点"),
            ("HP成长提升", "提升宝可梦的HP成长1点")
        ]

        stat_reward = random.choice(stat_rewards)

        return {
            'tool_rewards': tool_rewards,
            'stat_reward': stat_reward
        }
class Button:
    def __init__(self, x, y, width, height, text, action=None):
        self.rect = pygame.Rect(x, y, width, height)
        self.text = text
        self.action = action
        self.color = (60, 179, 113)  # 绿色
        self.hover_color = (50, 150, 100)  # 深绿色
        self.is_hovered = False
        self.font = pygame.font.SysFont('SimHei', 24)  # 减小字体大小

    def draw(self, screen):
        # 绘制按钮背景
        color = self.hover_color if self.is_hovered else self.color
        pygame.draw.rect(screen, color, self.rect)
        pygame.draw.rect(screen, (0, 0, 0), self.rect, 2)  # 黑色边框

        # 处理多行文本
        lines = self.text.split('\n')
        line_height = self.font.get_height()
        total_height = line_height * len(lines)
        start_y = self.rect.centery - total_height // 2

        # 绘制每一行文本
        for i, line in enumerate(lines):
            text_surface = self.font.render(line, True, (255, 255, 255))
            text_rect = text_surface.get_rect(
                centerx=self.rect.centerx,
                y=start_y + i * line_height
            )
            screen.blit(text_surface, text_rect)

    def handle_event(self, event):
        if event.type == pygame.MOUSEMOTION:
            self.is_hovered = self.rect.collidepoint(event.pos)
        elif event.type == pygame.MOUSEBUTTONDOWN:
            if event.button == 1:  # 左键点击
                if self.rect.collidepoint(event.pos) and self.action:
                    return self.action()  # 返回 action 的结果
        return None


class PokemonSlotView:
    def __init__(self, screen, player, pokemon_images, game_manager):
        self.screen = screen
        self.player = player
        self.pokemon_images = pokemon_images
        self.game_manager = game_manager
        self.state = "查看宝可梦"
        
        # 设置槽位布局参数
        self.screen_width = screen.get_width()
        self.screen_height = screen.get_height()
        self.slot_width = 200   # 槽位宽度保持不变
        self.slot_height = 250  # 槽位高度保持不变
        self.padding = 20
        
        # 设置替换按钮的尺寸（高度为槽位高度的1/5）
        button_width = 80               # 替换按钮宽度
        button_height = 50              # 替换按钮高度（原来是250，现在是50）
        
        # 计算起始位置，使槽位在屏幕中央
        total_width = (self.slot_width + self.padding) * 3 - self.padding
        total_height = (self.slot_height + self.padding) * 2 - self.padding
        start_x = (self.screen_width - total_width) // 2
        start_y = (self.screen_height - total_height) // 2
        
        # 创建槽位按钮
        self.slot_buttons = []
        for i in range(6):
            row = i // 3
            col = i % 3
            
            # 计算槽位位置
            slot_x = start_x + col * (self.slot_width + self.padding)
            slot_y = start_y + row * (self.slot_height + self.padding)
            
            # 计算替换按钮位置（在槽位底部居中）
            button_x = slot_x + (self.slot_width - button_width) // 2  # 水平居中
            button_y = slot_y + self.slot_height - button_height - 5   # 在槽位底部上方5像素
            
            slot_name = f"slot{i + 1}"
            button = Button(
                x=button_x,
                y=button_y,
                width=button_width,     # 使用新的按钮宽度
                height=button_height,   # 使用新的按钮高度
                text="替换",
                action=lambda s=slot_name: self.select_pokemon(s)
            )
            self.slot_buttons.append(button)

        # 设置槽位布局
        self.screen_width = screen.get_width()
        self.screen_height = screen.get_height()
        self.slot_width = 200
        self.slot_height = 250
        self.padding = 20

        # 创建返回按钮
        self.back_button = Button(
            self.screen_width - 150,
            self.screen_height - 60,
            120, 40,
            "返回",
            lambda: self.set_state("选择行动")
        )

    def is_slot_clicked(self, slot, mouse_pos):
        """检查鼠标点击是否在指定的卡槽上"""
        # 计算总宽度和高度
        total_width = (self.slot_width + self.padding) * 3 - self.padding
        total_height = (self.slot_height + self.padding) * 2 - self.padding
        start_x = (self.screen_width - total_width) // 2
        start_y = (self.screen_height - total_height) // 2

        # 获取槽位编号
        slot_num = int(slot.replace("slot", "")) - 1
        row = slot_num // 3
        col = slot_num % 3

        # 计算槽位位置
        x = start_x + col * (self.slot_width + self.padding)
        y = start_y + row * (self.slot_height + self.padding)

        # 检查点击是否在槽位范围内
        return (x <= mouse_pos[0] <= x + self.slot_width and 
                y <= mouse_pos[1] <= y + self.slot_height)

    def draw(self):
        # 绘制背景
        self.screen.fill((255,255,255))
            # 绘制标题
        font = pygame.font.SysFont('SimHei', 36)
        title = font.render("已有宝可梦", True, (0, 0, 0))
        title_rect = title.get_rect(center=(self.screen_width // 2, 50))
        self.screen.blit(title, title_rect)
            # 先绘制槽位的背景和宝可梦信息
        for i, button in enumerate(self.slot_buttons):
            slot_name = f"slot{i + 1}"
            pokemon_data = self.player.pokemon_slots.get(slot_name)
                # 绘制槽位背景
            pygame.draw.rect(self.screen, (60, 179, 113), button.rect)
            
            if pokemon_data:
                # 绘制宝可梦图片和信息
                if pokemon_data["name"] in self.pokemon_images:
                    image = self.pokemon_images[pokemon_data["name"]]
                    scaled_image = pygame.transform.scale(image, (150, 150))
                    image_rect = scaled_image.get_rect(
                        center=(button.rect.centerx, button.rect.y + 100)
                    )
                    self.screen.blit(scaled_image, image_rect)
                    # 绘制宝可梦信息
                font = pygame.font.SysFont('SimHei', 20)
                name_text = font.render(pokemon_data["name"], True, (0, 0, 0))
                self.screen.blit(name_text, (button.rect.x + 10, button.rect.y + 10))
                level_text = font.render(f"Lv.{pokemon_data['level']}", True, (0, 0, 0))
                self.screen.blit(level_text, (button.rect.x + self.slot_width - 60, button.rect.y + 10))
                hp_text = font.render(f"HP: {pokemon_data['Hp']}/{pokemon_data['HP']}", True, (0, 0, 0))
                self.screen.blit(hp_text, (button.rect.x + 10, button.rect.y + self.slot_height - 30))
            else:
                # 空槽位显示
                font = pygame.font.SysFont('SimHei', 24)
                empty_text = font.render("空槽位", True, (128, 128, 128))
                text_rect = empty_text.get_rect(center=button.rect.center)
                self.screen.blit(empty_text, text_rect)
            # 最后绘制所有按钮
        for button in self.slot_buttons:
            button.draw(self.screen)
        
        # 绘制返回按钮
        self.back_button.draw(self.screen)

    def handle_event(self, event):
        if event.type == pygame.MOUSEBUTTONDOWN:
            mouse_pos = pygame.mouse.get_pos()
            
            # 检查槽位按钮点击
            for button in self.slot_buttons:
                if button.rect.collidepoint(mouse_pos):
                    result = button.handle_event(event)
                    if result:  # 如果替换成功
                        return result  # 返回 "选择行动"
            
            # 检查返回按钮点击
            if self.back_button.rect.collidepoint(mouse_pos):
                return "选择行动"
        
        # 处理鼠标悬停效果
        if event.type == pygame.MOUSEMOTION:
            for button in self.slot_buttons:
                button.handle_event(event)
            self.back_button.handle_event(event)
        
        return None

    def set_state(self, new_state):
        self.state = new_state
        return self.state
    
    def select_pokemon(self, slot_name):
        """处理宝可梦选择"""
        # 1. 检查该槽位是否有可用宝可梦
        pokemon = self.player.pokemon_slots.get(slot_name)
        print(f"\n尝试选择槽位 {slot_name} 的宝可梦:")
        print(f"选中槽位的宝可梦: {pokemon['name'] if pokemon else '空'}")
        
        # 如果是第一槽位，直接返回
        if slot_name == "slot1":
            print("不能选择第一槽位，它已经是当前出战宝可梦")
            return None
            
        # 检查选中的槽位是否有可用宝可梦
        if pokemon and pokemon.get("Hp", 0) > 0:
            print(f"当前第一槽位宝可梦: {self.player.pokemon_slots['slot1']['name']}")
            
            # 2. 交换槽位
            temp = self.player.pokemon_slots["slot1"]
            self.player.pokemon_slots["slot1"] = pokemon
            self.player.pokemon_slots[slot_name] = temp
            
            print(f"\n交换后:")
            print(f"第一槽位: {self.player.pokemon_slots['slot1']['name']}")
            print(f"槽位 {slot_name}: {self.player.pokemon_slots[slot_name]['name']}")
            
            # 3. 保存更改
            self.game_manager.save_player_data(self.player)
            print("已保存更新后的槽位数据")
            
            # 4. 返回战斗界面
            return "选择行动"  # 这个返回值会通过 handle_event 传递到 BattleSystem
        
        return None
   

class BattleSystem:
    def __init__(self, screen, player, wild_poke,pokemon_images,game_manager):
        self.screen = screen
        self.player = player
        self.game_manager = game_manager
        self.pokemon_images = pokemon_images
        self.wild_poke = wild_poke
        self.player_poke = player.get_active_pokemon()
        self.pokemon_images = pokemon_images
        self.state = "选择行动"
        self.battle_message = ""
        self.message_time = 0
        self.buttons = self.create_buttons()
        self.tool_buttons = []
        self.back_button = Button(50, self.screen.get_height() - 70, 100, 40, "返回",
                                  lambda: self.set_state("选择行动"))
        # 加载战斗背景图片
        self.background = pygame.image.load("战斗背景.png").convert()
        self.paused = False

        self.victory_state = False
        self.rewards = []
        self.reward_buttons = []
        self.turn = "player"  # 添加回合标记，"player" 或 "wild"
        self.last_attack_time = 0  # 记录上次攻击时间
        self.attack_delay = 100  # 攻击延迟（毫秒）
        self.escape_attempts = 0
        self.pokemon_slot_view = PokemonSlotView(screen, player, pokemon_images,game_manager)
        self.paused = False
        # 加载已保存的玩家数据
        saved_pokemon = self.game_manager.load_player_data(player.name)
        saved_tools = self.game_manager.load_player_tools(player.name)

        if saved_pokemon:
            # 有保存数据，直接加载
            self.player.pokemon_slots = saved_pokemon
            # 获取第一个有效的宝可梦作为当前宝可梦
            for slot, poke in saved_pokemon.items():
                if poke and poke.get("Hp", 0) > 0:
                    self.player_poke = all_poke.PlayerPoke(poke)  # 转换为PlayerPoke对象
                    break
        else:
            # 新玩家，初始化槽位
            initial_pokemon = player.get_active_pokemon()
            if initial_pokemon:
                self.player_poke = all_poke.PlayerPoke(initial_pokemon)
                self.player.pokemon_slots = self.game_manager.initialize_player_slots(
                    player.name,
                    initial_pokemon
                )

        self.wild_poke = wild_poke

        self.create_tool_buttons()

    def try_escape(self):
        """尝试逃跑"""
        # 这里可以添加逃跑成功率的计算
        escape_chance = random.random()  # 生成0-1之间的随机数
        if escape_chance > 0.5:  # 50%的逃跑成功率
            self.battle_message = "逃跑成功！"
            self.message_time = pygame.time.get_ticks()
            return True
        return False

    def generate_rewards(self):
        """生成战斗胜利后的奖励选项"""
        # 从tools.json中随机选择两个道具
        if not self.game_manager.tools_data:
            print("Error: No tools data available")
            return

        available_tools = list(self.game_manager.tools_data[0].keys())
        tool_rewards = random.sample(available_tools, 2)

        # 定义能力提升选项
        stat_rewards = [
            ("ATK提升", "提升宝可梦的攻击力5点"),
            ("DEF提升", "提升宝可梦的防御力5点"),
            ("SPD提升", "提升宝可梦的速度5点"),
            ("HP提升", "提升宝可梦的最大HP5点"),
            ("ATK成长提升", "提升宝可梦的攻击成长1点"),
            ("DEF成长提升", "提升宝可梦的防御成长1点"),
            ("SPD成长提升", "提升宝可梦的速度成长1点"),
            ("HP成长提升", "提升宝可梦的HP成长1点")
        ]

        # 随机选择一个能力提升
        stat_reward = random.choice(stat_rewards)

        # 创建奖励按钮
        screen_width = self.screen.get_width()
        screen_height = self.screen.get_height()
        button_width = 200
        button_height = 50
        button_spacing = 50
        start_x = (screen_width - (button_width * 3 + button_spacing * 2)) // 2
        y = screen_height // 2

        self.reward_buttons = []

        # 添加两个道具按钮
        for i, tool_name in enumerate(tool_rewards):
            tool_data = self.game_manager.tools_data[0][tool_name]
            button_text = f"获得{tool_data['name']}"
            x = start_x + i * (button_width + button_spacing)

            def create_tool_action(t_name=tool_name):
                def action():
                    # 添加道具到玩家背包
                    if t_name in self.player.tools:
                        self.player.tools[t_name]['num'] += 1
                    else:
                        tool_data = all_tools.tool[t_name]
                        self.player.tools[t_name] = {
                            "name": tool_data.name,
                            "num": 1,
                            "ToolsType": tool_data.ToolsType,
                            "GetType": tool_data.GetType,
                            "BloodType": tool_data.BloodType,
                            "LifeType": tool_data.LifeType,
                            "PpType": getattr(tool_data, 'PpType', None)
                        }
                    self.game_manager.save_player_data(self.player)
                    self.battle_message = f"获得了 {t_name}!"
                    # 重置战斗状态
                    self.victory_state = False
                    self.wild_poke = randompoke.randompokes()
                    self.state = "选择行动"
                    self.turn = "player"

                return action

            self.reward_buttons.append(
                Button(x, y, button_width, button_height, button_text, create_tool_action())
            )

        # 添加属性提升按钮
        def create_stat_boost_action():
            def action():
                reward_name, description = stat_reward
                if isinstance(self.player_poke, dict):
                    if "ATK提升" == reward_name:
                        self.player_poke['ATK'] += 5
                    elif "DEF提升" == reward_name:
                        self.player_poke['DEF'] += 5
                    elif "SPD提升" == reward_name:
                        self.player_poke['SPD'] += 5
                    elif "HP提升" == reward_name:
                        self.player_poke['HP'] += 5
                        self.player_poke['Hp'] += 5
                    elif "ATK成长提升" == reward_name:
                        self.player_poke['ATK'] += 1
                    elif "DEF成长提升" == reward_name:
                        self.player_poke['DEF'] += 1
                    elif "SPD成长提升" == reward_name:
                        self.player_poke['SPD'] += 1
                    elif "HP成长提升" == reward_name:
                        self.player_poke['HP'] += 1
                        self.player_poke['Hp'] += 1
                else:
                    if "ATK提升" == reward_name:
                        self.player_poke.ATK += 5
                    elif "DEF提升" == reward_name:
                        self.player_poke.DEF += 5
                    elif "SPD提升" == reward_name:
                        self.player_poke.SPD += 5
                    elif "HP提升" == reward_name:
                        self.player_poke.HP += 5
                        self.player_poke.Hp += 5
                    elif "ATK成长提升" == reward_name:
                        self.player_poke.ATK += 1
                    elif "DEF成长提升" == reward_name:
                        self.player_poke.DEF += 1
                    elif "SPD成长提升" == reward_name:
                        self.player_poke.SPD += 1
                    elif "HP成长提升" == reward_name:
                        self.player_poke.HP += 1
                        self.player_poke.Hp += 1

                self.game_manager.save_player_data(self.player)
                self.battle_message = f"{self.player_poke['name'] if isinstance(self.player_poke, dict) else self.player_poke.name} 的{description}!"
                # 重置战斗状态
                self.victory_state = False
                self.wild_poke = randompoke.randompokes()
                self.state = "选择行动"
                self.turn = "player"

            return action

        x = start_x + 2 * (button_width + button_spacing)
        self.reward_buttons.append(
            Button(x, y, button_width, button_height, stat_reward[1], create_stat_boost_action())
        )

    def select_reward(self, reward):
        """处理奖励选择"""
        if reward["type"] == "item":
            if reward["name"] in self.player.tools:
                self.player.tools[reward["name"]]["num"] += reward["num"]
            else:
                self.player.tools[reward["name"]] = {
                    "name": reward["name"],
                    "num": reward["num"]
                }
        elif reward["type"] == "money":
            self.player.money += reward["amount"]
        elif reward["type"] == "exp":
            if isinstance(self.player_poke, dict):
                self.player_poke["EXP"] += reward["amount"]
            else:
                self.player_poke.exp_up(reward["amount"])

        # 保存数据
        self.game_manager.save_player_data(self.player)
        # 生成新的野生宝可梦
        self.wild_poke = randompoke.randompokes()
        self.victory_state = False
        self.state = "选择行动"

    def handle_tool_use(self, tool_name, target_poke):
        """处理道具使用"""
        if tool_name in self.player.tools:
            tool_data = self.player.tools[tool_name]
            
            # 检查道具数量
            if tool_data['num'] <= 0:
                self.battle_message = f"{tool_name}数量不足!"
                self.message_time = pygame.time.get_ticks()
                return False
            
            # 获取道具对象时，传入GetType
            tool_obj = all_tools.get_tool_by_name(tool_name, tool_data['num'], tool_data['GetType'])
            
            # 判断是否是捕获道具或神奇糖果
            is_special_tool = tool_data['ToolsType'] in [1, 8]  # 1是精灵球，8是神奇糖果
            
            # 如果是精灵球或神奇糖果，立即减少数量
            if is_special_tool:
                tool_data['num'] -= 1
                if tool_data['num'] <= 0:
                    del self.player.tools[tool_name]
            
            # 使用道具
            if tool_data['ToolsType'] == 1:  # 捕获道具
                success, messages = tool_obj.UseTools(self.wild_poke)
            else:
                success, messages = tool_obj.UseTools(target_poke)
            
            self.battle_message = "\n".join(messages)
            
            if success:
                # 如果不是精灵球或神奇糖果，在使用成后减少数量
                if not is_special_tool:
                    tool_data['num'] -= 1
                    if tool_data['num'] <= 0:
                        del self.player.tools[tool_name]
                
                if tool_data['ToolsType'] == 1:  # 捕获成功
                    empty_slot = self.game_manager.find_empty_slot(self.player)
                    if empty_slot:
                        self.player.pokemon_slots[empty_slot] = {
                            "name": self.wild_poke.name,
                            "attribute": self.wild_poke.attribute,
                            "attributes": self.wild_poke.attributes,
                            "level": self.wild_poke.level,
                            "ATK": self.wild_poke.ATK,
                            "DEF": self.wild_poke.DEF,
                            "SPD": self.wild_poke.SPD,
                            "ACC": self.wild_poke.ACC,
                            "HP": self.wild_poke.HP,
                            "Hp": self.wild_poke.Hp,
                            "EXP": 0,
                            "NeedEXP": self.wild_poke.NeedEXP,
                            "skills": self.wild_poke.skills,
                            "learn_skills": self.wild_poke.learn_skills
                        }
                        self.game_manager.save_player_data(self.player)
                        self.wild_poke = randompoke.randompokes()
                        self.state = "选择行动"
                        self.turn = "player"
                    else:
                        self.battle_message = "所有槽位已满，无法捕捉更多宝可梦!"
                else:
                    # 更新宝可梦状态
                    for slot, poke in self.player.pokemon_slots.items():
                        if poke and poke["name"] == target_poke.name:
                            poke.update({
                                "Hp": target_poke.Hp,
                                "HP": target_poke.HP,
                                "skills": target_poke.skills,
                                "ATK": target_poke.ATK,
                                "DEF": target_poke.DEF,
                                "SPD": target_poke.SPD
                            })
                            break
                    
                    # 更新战斗中宝可梦的状态和技能按钮
                    if self.player_poke and self.player_poke.name == target_poke.name:
                        self.player_poke = target_poke
                        self.update_skill_buttons()
                    
            self.game_manager.save_player_data(self.player)
            self.turn = "wild"
            self.last_attack_time = pygame.time.get_ticks()
            self.message_time = pygame.time.get_ticks()
            self.state = "选择行动"
            return success
            
        return False

    def update_skill_buttons(self):
        """更新技能按钮"""
        self.buttons["skill_menu"] = []
        screen_width = self.screen.get_width()
        screen_height = self.screen.get_height()
        button_width = 150
        button_height = 40
        button_spacing = 20
        
        for i, skill in enumerate(self.player_poke.skills):
            x = screen_width - 400 + (i % 2) * (button_width + button_spacing)
            y = screen_height - 200 + (i // 2) * (button_height + button_spacing)
            button_text = f"{skill['name']} ({skill['Pp']}/{skill['PP']})"
            self.buttons["skill_menu"].append(
                Button(x, y, button_width, button_height,
                       button_text,
                       lambda s=skill: self.use_skill(s))
            )

    def create_tool_buttons(self):
        """创建道具按钮"""
        screen_width = self.screen.get_width()
        screen_height = self.screen.get_height()
        button_width = 150
        button_height = 40
        button_spacing = 20

        start_y = 400
        buttons_per_row = 4
        self.tool_buttons = []
        if self.player.tools:
            for i, (tool_name, tool_data) in enumerate(self.player.tools.items()):
                # 计算按钮位置
                row = i // buttons_per_row
                col = i % buttons_per_row

                # 计算x坐标，使按钮在屏幕中央对齐
                total_width = (button_width + button_spacing) * buttons_per_row - button_spacing
                start_x = (screen_width - total_width) // 2

                x = start_x + col * (button_width + button_spacing)
                y = start_y + row * (button_height + button_spacing)

                text = f"{tool_name} x{tool_data['num']}"
                self.tool_buttons.append(
                    Button(x, y, button_width, button_height, text,
                           lambda t=tool_name: self.handle_tool_use(t, self.player_poke))
                )

    def handle_battle_end(self, result):
        """处理战斗结束"""
        if result == "win":
            # 基础经验值奖励
            exp = self.game_manager.get_exp(self.wild_poke)
            if isinstance(self.player_poke, dict):
                self.player_poke['EXP'] += exp
            else:
                self.player_poke.exp_up(exp)

            # 显示胜利信息
            pokemon_name = self.player_poke.name if hasattr(self.player_poke, 'name') else self.player_poke['name']
            self.battle_message = f"{pokemon_name} 获得了{exp}点经验！\n请选择一个奖励！"

            # 生成奖励选项
            self.victory_state = True
            self.generate_rewards()

            # 保存数据
            self.game_manager.save_player_data(self.player)
            return True
        return False

    def create_buttons(self):
        """创建战斗界面的按钮"""
        screen_width = self.screen.get_width()
        screen_height = self.screen.get_height()

        # 按钮尺寸和位置参数
        button_width = 150
        button_height = 40
        button_spacing = 20

        buttons = {
            "main_menu": [
                Button(screen_width - 400, screen_height - 200, button_width, button_height, "战斗",
                       lambda: self.set_state("选择技能")),
                Button(screen_width - 200, screen_height - 200, button_width, button_height, "道具",
                       lambda: self.set_state("背包")),
                Button(screen_width - 400, screen_height - 120, button_width, button_height, "宝可梦",
                       lambda: self.set_state("查看宝可梦")),
                Button(screen_width - 200, screen_height - 120, button_width, button_height, "逃跑",
                       self.try_escape)
            ],
            "skill_menu": []

        }

        # 处理技能按钮
        if self.player_poke and hasattr(self.player_poke, 'skills'):
            for i, skill in enumerate(self.player_poke.skills):
                x = screen_width - 400 + (i % 2) * (button_width + button_spacing)
                y = screen_height - 200 + (i // 2) * (button_height + button_spacing)

                # 根据技能的数据类型来获取技能名称
                if isinstance(skill, dict):
                    skill_name = skill["name"]
                    pp_text = f" ({skill.get('Pp', 0)}/{skill.get('PP', 0)})"
                    button_text = skill_name + pp_text
                else:
                    button_text = str(skill)

                buttons["skill_menu"].append(
                    Button(x, y, button_width, button_height,
                           button_text,
                           lambda s=skill: self.use_skill(s))
                )
        buttons["main_menu"].append(
            Button(screen_width - 400, screen_height - 120, button_width, button_height,
                   "宝可梦", lambda: self.set_state("查看宝可梦"))
        )
        return buttons

    def set_state(self, new_state):
        """设置战斗状态"""
        self.state = new_state
        if new_state == "背包":
            self.create_tool_buttons()
        elif new_state == "选择技能":
            self.update_skill_buttons()
        else:
            self.tool_buttons = []  # 清空道具按钮列表
    def try_escape(self):
        """尝试逃跑"""
        self.battle_message = "成功逃跑！"
        self.message_time = pygame.time.get_ticks()
        return True

    def use_skill(self, skill):
        """使用技能"""
        # 1. 获取技能对象并使用
        skill_obj = all_skills.get_skill_by_name(skill["name"], skill["Pp"])
        damage = skill_obj.apply(self.player_poke, self.wild_poke)
        
        if damage > 0:
            # 2. 应用伤害和消耗PP
            skill["Pp"] -= 1
            all_skills.ApplyDmage(self.player_poke, self.wild_poke, damage, skill_obj)
            
            # 3. 更新槽位中的PP值
            for slot, poke in self.player.pokemon_slots.items():
                if poke and poke["name"] == self.player_poke.name:
                    # 找到对应的技能并更新PP值
                    for slot_skill in poke["skills"]:
                        if slot_skill["name"] == skill["name"]:
                            slot_skill["Pp"] = skill["Pp"]
                    break
            
            # 4. 更新战斗UI
            for button in self.buttons["skill_menu"]:
                if button.text.startswith(skill["name"]):
                    button.text = f"{skill['name']} ({skill['Pp']}/{skill['PP']})"
            
            # 5. 设置战斗消息
            pokemon_name = self.player_poke.name if hasattr(self.player_poke, 'name') else self.player_poke['name']
            self.battle_message = f"{pokemon_name}使用了{skill['name']}，造成{damage}点伤害!"
            self.message_time = pygame.time.get_ticks()
            
            # 6. 切换战斗状态
            self.state = "选择行动"
            self.turn = "wild"
            self.last_attack_time = pygame.time.get_ticks()
            
            # 7. 保存游戏数据
            self.game_manager.save_player_data(self.player)

    def wild_pokemon_attack(self):
        """野生宝可梦的攻击"""
        if not hasattr(self.wild_poke, 'skills'):
            return

        # 随机选择一个技能
        available_skills = [s for s in self.wild_poke.skills if s.get("Pp", 0) > 0]
        if not available_skills:
            return

        skill = random.choice(available_skills)
        skill_obj = all_skills.get_skill_by_name(skill["name"], skill["Pp"])
        damage = skill_obj.apply(self.wild_poke, self.player_poke)
        skill["Pp"] -= 1

        # 对玩家宝可梦造成伤害
        all_skills.ApplyDmage(self.wild_poke, self.player_poke, damage, skill_obj)

        # 设置战斗消息
        self.battle_message = f"野生的{self.wild_poke.name}使用了{skill['name']}，造成{damage}点伤害!"
        self.message_time = pygame.time.get_ticks()

        # 切换回玩家回合
        self.turn = "player"
    def calculate_damage(self, skill_obj,is_wild=False):
        """计算伤害"""
        base_damage = skill_obj.power
        if is_wild:
            # 野生宝可梦攻击玩家
            if isinstance(self.wild_poke, dict):
                attack = self.wild_poke['ATK']
            else:
                attack = self.wild_poke.ATK

            if isinstance(self.player_poke, dict):
                defense = self.player_poke['DEF']
            else:
                defense = self.player_poke.DEF
        else:
            # 玩家攻击野生宝可梦
            if isinstance(self.player_poke, dict):
                attack = self.player_poke['ATK']
            else:
                attack = self.player_poke.ATK

            if isinstance(self.wild_poke, dict):
                defense = self.wild_poke['DEF']
            else:
                defense = self.wild_poke.DEF

        damage = (base_damage * attack / defense) * random.uniform(0.85, 1.0)
        return int(damage)

    def handle_event(self, event):
        if self.state =="查看宝可梦":
            new_state = self.pokemon_slot_view.handle_event(event)
            if new_state:
                # 更新当前战斗中的宝可梦（使用第一槽位的宝可梦）
                slot1_pokemon = self.player.pokemon_slots.get("slot1")
                if slot1_pokemon:  # 检查第一槽位是否有宝可梦
                    self.player_poke = all_poke.PlayerPoke(slot1_pokemon)
                    self.battle_message = f"切换到了 {self.player_poke.name}!"
                    self.message_time = pygame.time.get_ticks()
                    self.turn = "wild"
                    self.last_attack_time = pygame.time.get_ticks()
                self.state = new_state
        elif self.state == "选择行动":
            if event.type == pygame.MOUSEBUTTONDOWN:  # 添加这个判断
                mouse_pos = event.pos  # 从事件中获取鼠标位置
                for button in self.buttons["main_menu"]:
                    if button.rect.collidepoint(mouse_pos):
                        if button.text == "战斗":
                            self.set_state("选择技能")
                            return
                        elif button.text == "道具":
                            self.set_state("背包")
                            return
                        elif button.text == "宝可梦":
                            self.set_state("查看宝可梦")
                            return
                        elif button.text == "逃跑":
                            if self.try_escape():
                                # 逃跑成功，生成新的野生宝可梦
                                self.wild_poke = randompoke.randompokes()
                                self.battle_message = f"遇到了野生的{self.wild_poke.name}!"
                                self.message_time = pygame.time.get_ticks()
                                self.state = "选择行动"
                                self.turn = "player"
                                return "escaped"
                            else:
                                # 逃跑失败，切换到野生宝可梦的回合
                                self.battle_message = "逃跑失败！"
                                self.message_time = pygame.time.get_ticks()
                                self.turn = "wild"
                                self.last_attack_time = pygame.time.get_ticks()
                                return

        # 处理ESC键暂停
        if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
            self.paused = not self.paused
            return

        # 如果游戏暂停，不处理其他事件
        if self.paused:
            return

        # 处理宝可梦查看界面
        if self.state == "查看宝可梦":
            if event.type == pygame.MOUSEBUTTONDOWN:
                # 添加返回按钮的处理
                if event.pos[1] > self.screen.get_height() - 50:  # 假设返回按钮在底部
                    self.state = "选择行动"
                    return

        # 处理鼠标点击事件
        if event.type == pygame.MOUSEBUTTONDOWN:
            mouse_pos = pygame.mouse.get_pos()

            # 处理胜利状态下的奖励选择
            if self.victory_state:
                for button in self.reward_buttons:
                    if button.rect.collidepoint(mouse_pos):
                        if button.action:
                            button.action()
                        return
                return

            # 处理不同状态下的按钮点击
            if self.state == "背包":
                # 处理返回按钮
                if self.back_button.rect.collidepoint(mouse_pos):
                    self.back_button.action()
                    return

                # 处理道具按钮
                for button in self.tool_buttons:
                    if button.rect.collidepoint(mouse_pos):
                        if button.action:
                            button.action()
                        return

            elif self.state == "选择行动":
                # 处理主菜单按钮
                for button in self.buttons["main_menu"]:
                    if button.rect.collidepoint(mouse_pos):
                        if button.text == "逃跑":
                            if self.try_escape():
                                # 逃跑成功，生成新的野生宝可梦
                                self.wild_poke = randompoke.randompokes()
                                self.battle_message = f"遇到了野生的{self.wild_poke.name}!"
                                self.state = "选择行动"
                                self.turn = "player"
                                return "escaped"
                            else:
                                # 逃跑失败，切换到野生宝可梦的回合
                                self.turn = "wild"
                                self.last_attack_time = pygame.time.get_ticks()
                        elif button.action:
                            button.action()
                        return

            elif self.state == "选择技能":
                # 处理技能按钮
                for button in self.buttons["skill_menu"]:
                    if button.rect.collidepoint(mouse_pos):
                        if button.action:
                            button.action()
                        return
    def update(self):
        """更新战斗状态"""
        # 检查宝可梦是否存活
        current_time = pygame.time.get_ticks()
        # 处理捕获成功后的延迟
        if self.state == "等待新战斗" and hasattr(self, 'capture_success'):
            if current_time - self.capture_time >= 2000:  # 2秒延迟
                # 生成新的野生宝可梦
                import randompoke
                self.wild_poke = randompoke.randompokes()
                self.battle_message = f"遇到了野生的{self.wild_poke.name}!"
                self.message_time = current_time
                self.state = "选择行动"
                self.turn = "player"
                self.capture_success = False
                return "continue"
            return "continue"

        if isinstance(self.wild_poke, dict):
            wild_hp = self.wild_poke['Hp']
        else:
            wild_hp = self.wild_poke.Hp

        if isinstance(self.player_poke, dict):
            player_hp = self.player_poke['Hp']
        else:
            player_hp = self.player_poke.Hp

        if wild_hp <= 0:
            return "win"
        if player_hp <= 0:
            return "lose"

            # 如果是野生宝可梦的回合且已经过了延迟时间
        if self.turn == "wild" and current_time - self.last_attack_time >= self.attack_delay:
            self.wild_pokemon_attack()

        return "continue"

    def draw(self):
        """绘制战斗场景"""
        # 绘制背景
        self.screen.blit(self.background, (0, 0))

        # 绘制宝可梦状态
        if self.state !="等待新战斗":
          self.draw_pokemon_status(self.player_poke, True)
          self.draw_pokemon_status(self.wild_poke, False)

        # 绘制战斗消息
        if self.battle_message and pygame.time.get_ticks() - self.message_time < 2000:
            self.draw_battle_message()

        # 根据状态绘制不同的按钮
        if self.state == "选择行动":
            for button in self.buttons["main_menu"]:
                button.draw(self.screen)
        elif self.state == "选择技能":
            for button in self.buttons["skill_menu"]:
                button.draw(self.screen)
            # 添加返回按钮
            font = pygame.font.SysFont('SimHei', 32)
            back_text = font.render("返回", True, (0, 0, 0))
            back_rect = back_text.get_rect(center=(self.screen.get_width() // 2, self.screen.get_height() - 30))
            self.screen.blit(back_text, back_rect)
        elif self.state == "背包":
            for button in self.tool_buttons:
                button.draw(self.screen)
            if hasattr(self, 'back_button'):
                self.back_button.draw(self.screen)

        if self.victory_state:
            # 绘制胜利界面和奖励选择按钮
            victory_font = pygame.font.SysFont('SimHei', 48)
            text = victory_font.render("战斗胜利！", True, (255, 215, 0))
            text_rect = text.get_rect(center=(self.screen.get_width() // 2, self.screen.get_height() // 3))
            self.screen.blit(text, text_rect)

            # 绘制奖励按钮
            for button in self.reward_buttons:
                button.draw(self.screen)
        elif self.state == "查看宝可梦":
            self.pokemon_slot_view.draw()
            # 绘制返回按钮
            font = pygame.font.SysFont('SimHei', 32)
            back_text = font.render("返回", True, (0, 0, 0))
            back_rect = back_text.get_rect(center=(self.screen.get_width() // 2, self.screen.get_height() - 30))
            self.screen.blit(back_text, back_rect)
    def draw_pokemon_status(self, pokemon, is_player):
        """绘制宝可梦状态"""
        if not pokemon:  # 添加检查
            return

        x = 50 if is_player else self.screen.get_width() - 250
        y = self.screen.get_height() - 200 if is_player else 50

        # 根据对象类型获取属性
        if isinstance(pokemon, dict):
            # 如果是字典类型（玩家宝可梦）
            name = pokemon['name']
            level = pokemon['level']
            current_hp = pokemon['Hp']
            max_hp = pokemon['HP']
        else:
            # 如果是wildpoke对象（野生宝可梦）
            name = pokemon.name
            level = pokemon.level
            current_hp = pokemon.Hp
            max_hp = pokemon.HP

            # 使用实例变量self.pokemon_images
            if name in self.pokemon_images:
                image = self.pokemon_images[name]
                # 调整图片大小
                image = pygame.transform.scale(image, (300, 300))  # 可以调整图片大小

                # 玩家和敌方宝可梦的不同位置
                if is_player:
                    # 玩家宝可梦位置（左下）
                    image_x = x + 200  # 向右偏移50像素
                    image_y = y - 220  # 向上偏移180像素
                else:
                    # 敌方宝可梦位置（右上）
                    image_x = x - 100  # 向左偏移50像素
                    image_y = y + 50  # 向下偏移50像素

                self.screen.blit(image, (image_x, image_y))
            else:
                print(f"Warning: Image not found for pokemon {name}")
        # 绘制名字和等级
        font = pygame.font.SysFont('SimHei', 32)
        text = f"{name} Lv.{level}"
        text_surface = font.render(text, True, (0, 0, 0))
        self.screen.blit(text_surface, (x, y))

        # 绘制HP条
        hp_percent = current_hp / max_hp
        pygame.draw.rect(self.screen, (0, 0, 0), (x, y + 30, 200, 20), 2)
        pygame.draw.rect(self.screen, (60, 179, 113), (x, y + 30, 200 * hp_percent, 20))

    def draw_battle_message(self):
        """绘制战斗消息"""
        font = pygame.font.SysFont('SimHei', 32)
        text_surface = font.render(self.battle_message, True, (0, 0, 0))
        text_rect = text_surface.get_rect(center=(self.screen.get_width() // 2, 100))
        self.screen.blit(text_surface, text_rect)


def battle(player, wild_poke,pokemon_images):
    """战斗主函数"""
    screen = pygame.display.get_surface()
    clock = pygame.time.Clock()
    battle_system = BattleSystem(screen, player, wild_poke,pokemon_images)
    game_manager = GameManager()

    running = True
    while running:
        clock.tick(60)
        for event in pygame.event.get():
            if event.type == QUIT:
                running = False
            result = battle_system.handle_event(event)
            # 处理逃跑成功的情况
            if result == "escaped":
                # 不需要做任何特殊处理，因为BattleSystem已经生成了新的野生宝可梦
                continue

        battle_result = battle_system.update()
        if battle_result != "continue":
            if battle_system.handle_battle_end(battle_result):
                game_manager.reward(player)
            return battle_result

        battle_system.draw()
        pygame.display.flip()