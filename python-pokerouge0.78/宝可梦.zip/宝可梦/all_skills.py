import globals
import json
from enum  import IntEnum,unique
#将技能分成几类，让后将这几类的函数写出来，然后用type来表示类型
#（（攻击方等级×2÷5+2））×技能威力×攻击方攻击÷防守方能力值÷50+2）×（85～100）÷100

try:
    @unique
    class ObjOfAction(IntEnum):
        #这里是执行对象的标志
        self=1,
        other=2,
        self_abl=4,
        abl=8,
        blood_atk=16
    class EffectType(IntEnum):
        all_blood = 1
        half_blood = 2
        half_half_blood = 4
except ValueError as e:
    print(e)

def calc_hurt (poke_self,poke,skill):
    hurt = skill.hurt
    hurt = ((poke_self * 2 / 5 + 2) * hurt * poke_self.ATK / poke.DEF / 50 + 2)
    if poke.attribute in poke_self.attributes  :
        hurt = 2 * hurt
    if poke.attribute in skill.attributes:
        hurt = 1.5 * hurt
    if poke.HP > 0:
        return hurt

def calc_blood (poke_self,skill):
    if skill.EffectType == 1:
        return -poke_self.HP
    elif skill.EffectType == 2:
        return -(poke_self.HP)/2
    elif skill.EffectType == 4 :
        return -(poke_self.HP)/4


def get_hurt (poke,hurt):
    if poke.HP - hurt < 0:
        poke.HP = 0
    else :
        poke.HP =poke.HP - hurt

def get_blood (poke,blood):
    if poke.HP + poke.blood > poke.HP:
        poke.Hp = poke.HP   #这里需要改：第一个poke.HP应该是真实HP，而第二个是最大HP
    else :
        poke.Hp = poke.Hp + blood #同上

def ApplyDmage(poke,damage,is_recover=False):
    damage = int(damage)
    if is_recover == False :
        if damage ==0:
            print("似乎对{}没造成伤害".format(poke.nae))
        elif damage < 0:
            return
    else :
        if damage >=0 :
            return
    if is_recover == False :
        get_hurt(poke,damage)
    else :
        get_blood(poke,damage)

    #对poke的属性操作的结束阶段

class skill_base:
    def __init__(self,name,hurt,ACC,PP,attributes,attribute,skill_type,blood_type):
        self.name =name
        self.hurt = hurt
        self.ACC = ACC
        self.PP = PP
        self.attributes = attributes
        self.attribute = attribute
        self.skill_type = skill_type
        self.blood_type = blood_type


    def Apply(self,poke_self,poke_target,poke):
        ##效果: 检查技能释放机会是否足够 -> 检查技能是否命中 -> 寻找执行对象 和 执行类型
        damage = 0
        if not self.Ifpp():
            print("{}的pp用完了！".format(self.name))
            return damage
        print ("{}使用了{}".format(poke_self.name,self.name))
        if not globals.Porn(self,poke_self):
            self.sideEfeect()
            return damage
        if poke_self.IsAlive() and  self.skill_type & ObjOfAction.other : #这里的对象是目标
            damage = calc_hurt(poke_self,poke,self)
            ApplyDmage(poke,damage)
        if poke_self.IsAlive() and self.skill_type & ObjOfAction.self :
            blood = calc_blood(poke_target,self)
            ApplyDmage(poke,blood)

    def Ifpp(self):
        if self.pp > 0:
            self.pp = self.pp - 1
            return True
    def sideEfeect(self,poke_self,poke):
        pass



skills = {}

with open('skills.json', 'r', encoding='utf-8') as skill:
    skill_data = json.load(skill)
    for skill_name, skill_attributes in skill_data.items():
        # 将技能信息转为 Skill 类实例
        skills[skill_name] = skill_base(**skill_attributes)

