# all_tools.py
from enum import IntEnum, unique
import json

try:
    @unique
    class ToolsType(IntEnum):
        #道具类型
        get_poke = 1
        get_blood = 2
        get_abl = 4
        get_level = 8
        get_life = 16

    class GetType(IntEnum):
        Get1 = 1 #系数为 1
        Get2 = 2 #系数为 1.5
        Get3 = 3 #系数为3
        Get4 = 4 #系数为4

    class BloodType(IntEnum):
        Blood1 = 1 #20HP
        Blood2 = 2 #60HP
        Blood3 = 4 #120HP
        all_Blood = 8 #全部HP

    class LifeType(IntEnum):
        life = 1 #复活，获得50%Hp
        life_all = 2 #复活，获得全部Hp
except ValueError as e:
    print(e)

def get_tool_by_name(tool_name, num):
    """根据道具名称获取道具实例"""
    if tool_name in tool:  # 使用全局的tool字典
        tool_instance = tool[tool_name]
        new_tool = tools(
            name=tool_instance.name,
            num=num,
            ToolsType=tool_instance.ToolsType,
            GetType=tool_instance.GetType,
            BloodType=tool_instance.BloodType,
            LifeType=tool_instance.LifeType
        )
        return new_tool
    return None

def check_tool_type(tool, type_flag):
    """检查道具是否具有特定类型"""
    return bool(tool.ToolsType & type_flag)

class tools:
    def __init__(self, name, num, ToolsType, GetType=None, BloodType=None, LifeType=None):
        self.name = name
        self.num = num
        self.ToolsType = ToolsType
        self.GetType = GetType
        self.BloodType = BloodType
        self.LifeType = LifeType

    def UseTools(self,poke):
        if self.ToolsType

tool = {}

with open('tools.json', 'r+', encoding="utf-8") as temp:
    data = json.loads(temp.read())
    for tool_id, attributes in data[0].items():
        attributes['ToolsType'] = ToolsType(attributes['ToolsType'])
        if attributes.get('GetType') not in [None, 0]:
            attributes['GetType'] = GetType(attributes['GetType'])
        else:
            attributes['GetType'] = None

        if attributes.get('BloodType') not in [None, 0]:
            attributes['BloodType'] = BloodType(attributes['BloodType'])
        else:
            attributes['BloodType'] = None

        if attributes.get('LifeType') not in [None, 0]:
            attributes['LifeType'] = LifeType(attributes['LifeType'])
        else:
            attributes['LifeType'] = None

        # 创建道具实例
        tool[tool_id] = tools(**attributes)

print(tool)