import random
class rule_A:
    Fire = ["Grass", "Insects"]
    Water = ["Fire","Earth"]
    Earth = ["Fire","Poison"]
    Poison = ["Grass","Water"]
    Grass = ["Water","Soil"]
    Insect = ["Grass"]

def weighted_random(ACC):
    base_weights = [1, 1, 1, 1, 1, 1]
    acc_factor = ACC / 100

    for i in range(3, 6):
        base_weights[i] += acc_factor * 10

    total_weight = sum(base_weights)
    cumulative_weights = [sum(base_weights[:i+1]) / total_weight for i in range(6)]

    rand = random.random()
    for i, cw in enumerate(cumulative_weights):
        if rand < cw:
            return i + 1

def Porn(skill,poke_self):
    ACC = skill.ACC + poke_self
    if ACC <=100 :
        return weighted_random(ACC)
    